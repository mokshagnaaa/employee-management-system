//package com.example.dao;
//
//import java.sql.*;
//import java.util.ArrayList;
//import java.util.List;
//
//import com.example.model.Employee;
//import com.example.util.DBConnection;
//
//public class EmployeeDAO {
//    
//    public void addEmployee(Employee employee) throws SQLException {
//        String query = "INSERT INTO Employees (name, email, department, performance_score, attendance) VALUES (?, ?, ?, ?, ?)";
//        try (Connection con = DBConnection.getConnection();
//             PreparedStatement pst = con.prepareStatement(query)) {
//            pst.setString(1, employee.getName());
//            pst.setString(2, employee.getEmail());
//            pst.setString(3, employee.getDepartment());
//            pst.setInt(4, employee.getPerformanceScore());
//            pst.setInt(5, employee.getAttendance());
//            pst.executeUpdate();
//        }
//    }
//
//    public List<Employee> getAllEmployees() throws SQLException {
//        List<Employee> employees = new ArrayList<>();
//        String query = "SELECT * FROM Employees";
//        try (Connection con = DBConnection.getConnection();
//             Statement stmt = con.createStatement();
//             ResultSet rs = stmt.executeQuery(query)) {
//            while (rs.next()) {
//                Employee employee = new Employee();
//                employee.setId(rs.getInt("id"));
//                employee.setName(rs.getString("name"));
//                employee.setEmail(rs.getString("email"));
//                employee.setDepartment(rs.getString("department"));
//                employee.setPerformanceScore(rs.getInt("performance_score"));
//                employee.setAttendance(rs.getInt("attendance"));
//                employees.add(employee);
//            }
//        }
//        return employees;
//    }
//
//    public void updateEmployee(Employee employee) throws SQLException {
//        String query = "UPDATE Employees SET name=?, email=?, department=?, performance_score=?, attendance=? WHERE id=?";
//        try (Connection con = DBConnection.getConnection();
//             PreparedStatement pst = con.prepareStatement(query)) {
//            pst.setString(1, employee.getName());
//            pst.setString(2, employee.getEmail());
//            pst.setString(3, employee.getDepartment());
//            pst.setInt(4, employee.getPerformanceScore());
//            pst.setInt(5, employee.getAttendance());
//            pst.setInt(6, employee.getId());
//            pst.executeUpdate();
//        }
//    }
//
//    public void deleteEmployee(int id) throws SQLException {
//        String query = "DELETE FROM Employees WHERE id=?";
//        try (Connection con = DBConnection.getConnection();
//             PreparedStatement pst = con.prepareStatement(query)) {
//            pst.setInt(1, id);
//            pst.executeUpdate();
//        }
//    }
//}


package com.example.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.example.model.Employee;
import com.example.util.DBConnection;

public class EmployeeDAO {
    
    public void addEmployee(Employee employee) throws SQLException {
        String query = "INSERT INTO Employees (name, email, department, performance_score, attendance) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, employee.getName());
            pst.setString(2, employee.getEmail());
            pst.setString(3, employee.getDepartment());
            pst.setInt(4, employee.getPerformanceScore());
            pst.setInt(5, employee.getAttendance());
            pst.executeUpdate();
        }
    }

    public List<Employee> getAllEmployees() throws SQLException {
        List<Employee> employees = new ArrayList<>();
        String query = "SELECT * FROM Employees";
        try (Connection con = DBConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Employee employee = new Employee();
                employee.setId(rs.getInt("id"));
                employee.setName(rs.getString("name"));
                employee.setEmail(rs.getString("email"));
                employee.setDepartment(rs.getString("department"));
                employee.setPerformanceScore(rs.getInt("performance_score"));
                employee.setAttendance(rs.getInt("attendance"));
                employees.add(employee);
            }
        }
        return employees;
    }

    public void updateEmployee(Employee employee) throws SQLException {
        String query = "UPDATE Employees SET name=?, email=?, department=?, performance_score=?, attendance=? WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, employee.getName());
            pst.setString(2, employee.getEmail());
            pst.setString(3, employee.getDepartment());
            pst.setInt(4, employee.getPerformanceScore());
            pst.setInt(5, employee.getAttendance());
            pst.setInt(6, employee.getId());
            pst.executeUpdate();
        }
    }

    public void deleteEmployee(int id) throws SQLException {
        String query = "DELETE FROM Employees WHERE id=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, id);
            pst.executeUpdate();
        }
    }
}
