//package com.example.servlet;
//
//import com.example.model.Employee;
//import com.example.service.EmployeeService;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.List;
//
//@WebServlet("/viewEmployees")
//public class ViewAllEmployeesServlet extends HttpServlet {
//    private static final long serialVersionUID = 1L;
//    private EmployeeService employeeService;
//
//    @Override
//    public void init() throws ServletException {
//        super.init();
//        employeeService = new EmployeeService();
//    }
//
//    @Override
//    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        List<Employee> employees = employeeService.getAllEmployees();
//        response.setContentType("text/html");
//        PrintWriter out = response.getWriter();
//        try {
//            for (Employee employee : employees) {
//                out.println(employee.toString() + "<br>");
//            }
//        } finally {
//            out.close();
//        }
//    }
//}
package com.example.servlet;

import com.example.model.Employee;
import com.example.service.EmployeeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/viewEmployees")
public class ViewAllEmployeesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private EmployeeService employeeService;

    @Override
    public void init() {
        employeeService = new EmployeeService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Employee> employees = employeeService.getAllEmployees();
        System.out.println("Employees fetched: " + employees); 
        request.setAttribute("employees", employees);
        request.getRequestDispatcher("viewEmployees.jsp").forward(request, response);
    }
}

