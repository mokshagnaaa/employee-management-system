package com.example.servlet;

import com.example.model.Employee;
import com.example.service.EmployeeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/addEmployee")
public class AddEmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private EmployeeService employeeService;

    @Override
    public void init() {
        employeeService = new EmployeeService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String department = request.getParameter("department");
        String performanceScoreStr = request.getParameter("performanceScore");
        String attendanceStr = request.getParameter("attendance");

        try {
            int performanceScore = Integer.parseInt(performanceScoreStr);
            int attendance = Integer.parseInt(attendanceStr);

            Employee employee = new Employee();
            employee.setName(name);
            employee.setEmail(email);
            employee.setDepartment(department);
            employee.setPerformanceScore(performanceScore);
            employee.setAttendance(attendance);

            employeeService.addEmployee(employee);
            response.sendRedirect("/emsystem/viewEmployees");

        } catch (NumberFormatException e) {
            request.setAttribute("errorMessage", "Invalid input: Performance Score and Attendance must be integers.");
            request.getRequestDispatcher("/addEmployee.jsp").forward(request, response);
        } catch (RuntimeException e) {
            request.setAttribute("errorMessage", "Error adding employee: " + e.getMessage());
            request.getRequestDispatcher("/addEmployee.jsp").forward(request, response);
        }
    }
}
