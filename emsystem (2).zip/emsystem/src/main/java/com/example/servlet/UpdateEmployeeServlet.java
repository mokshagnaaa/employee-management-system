package com.example.servlet;

import com.example.model.Employee;
import com.example.service.EmployeeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Logger;

@WebServlet("/updateEmployee")
public class UpdateEmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private EmployeeService employeeService;
    private static final Logger logger = Logger.getLogger(UpdateEmployeeServlet.class.getName());

    public void init() {
        employeeService = new EmployeeService();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String department = request.getParameter("department");
            int performanceScore = Integer.parseInt(request.getParameter("performanceScore"));
            int attendance = Integer.parseInt(request.getParameter("attendance"));

            Employee employee = new Employee();
            employee.setId(id);
            employee.setName(name);
            employee.setEmail(email);
            employee.setDepartment(department);
            employee.setPerformanceScore(performanceScore);
            employee.setAttendance(attendance);

            employeeService.updateEmployee(employee);
            response.sendRedirect("index.jsp");
        } catch (Exception e) {
            logger.severe("Error while updating employee: " + e.getMessage());
            request.setAttribute("errorMessage", "Error updating employee. Please try again.");
            request.getRequestDispatcher("/update_employee.jsp").forward(request, response);
        }
    }
}
