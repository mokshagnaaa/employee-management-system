package com.example.servlet;

import com.example.service.EmployeeService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/deleteEmployee")
public class DeleteEmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private EmployeeService employeeService;

    @Override
    public void init() throws ServletException {
        super.init();
        employeeService = new EmployeeService();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String department = request.getParameter("department");

        System.out.println("Received delete request with name: " + name + " and department: " + department);

        if (name == null || name.isEmpty() || department == null || department.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Name and department are required");
            return;
        }

        try {
            boolean deleted = employeeService.deleteEmployeeByNameAndDepartment(name, department);
            if (deleted) {
                System.out.println("Employee successfully deleted.");
                response.sendRedirect(request.getContextPath() + "/index.jsp");
            } else {
                System.out.println("Employee not found.");
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Employee not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An unexpected error occurred: " + e.getMessage());
        }
    }
}
