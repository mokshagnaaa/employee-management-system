package com.example.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {

    private static final String URL = "jdbc:postgresql://localhost:5432/EmployeeDB";
    private static final String USER = "postgres";
    private static final String PASSWORD = "aarsha";

    static {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.err.println("PostgreSQL JDBC Driver not found. Include it in your library path.");
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void createTable() {
        String createTableSQL = """
            CREATE TABLE IF NOT EXISTS employee (
                id SERIAL PRIMARY KEY,
                column1 VARCHAR(255),
                column2 INT
            );
        """;

        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(createTableSQL);
            System.out.println("Table created successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Table creation failed.");
        }
    }
}
