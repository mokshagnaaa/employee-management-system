//	package com.example.model;
//	
//	
//	public class Employee {
//	    private int id;
//	    private String name;
//	    private String email;
//	    private String department;
//	    private int performanceScore;
//	    private int attendance;
//	
//	    // Getters and Setters
//	    public int getId() {
//	        return id;
//	    }
//	
//	    public void setId(int id) {
//	        this.id = id;
//	    }
//	
//	    public String getName() {
//	        return name;
//	    }
//	
//	    public void setName(String name) {
//	        this.name = name;
//	    }
//	
//	    public String getEmail() {
//	        return email;
//	    }
//	
//	    public void setEmail(String email) {
//	        this.email = email;
//	    }
//	
//	    public String getDepartment() {
//	        return department;
//	    }
//	
//	    public void setDepartment(String department) {
//	        this.department = department;
//	    }
//	
//	    public int getPerformanceScore() {
//	        return performanceScore;
//	    }
//	
//	    public void setPerformanceScore(int performanceScore) {
//	        this.performanceScore = performanceScore;
//	    }
//	
//	    public int getAttendance() {
//	        return attendance;
//	    }
//	
//	    public void setAttendance(int attendance) {
//	        this.attendance = attendance;
//	    }
//	
//	    @Override
//	    public String toString() {
//	        return "Employee [ID=" + id + ", Name=" + name + ", Email=" + email + ", Department=" + department +
//	               ", Performance Score=" + performanceScore + ", Attendance=" + attendance + "]";
//	    }
//	}


package com.example.model;

public class Employee {
    private int id;
    private String name;
    private String email;    
    private int employeeId;
    private String department;
    private int performanceScore;
    private int attendance;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getPerformanceScore() {
        return performanceScore;
    }

    public void setPerformanceScore(int performanceScore) {
        this.performanceScore = performanceScore;
    }

    public int getAttendance() {
        return attendance;
    }

    public void setAttendance(int attendance) {
        this.attendance = attendance;
    }

    @Override
    public String toString() {
        return "Employee [ID=" + id + ", Name=" + name + ", Email=" + email + ", EmployeeId=" + employeeId + ",Department=" + department +
               ", Performance Score=" + performanceScore + ", Attendance=" + attendance + "]";
    }

	public void setEmployeeId(String email2) {
		// TODO Auto-generated method stub
		
	}
}
