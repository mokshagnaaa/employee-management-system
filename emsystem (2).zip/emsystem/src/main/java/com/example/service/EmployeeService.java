//package com.example.service;
//
//import com.example.model.Employee;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.logging.Logger;
//
//public class EmployeeService {
//
//    private static final Logger logger = Logger.getLogger(EmployeeService.class.getName());
//
//    private static final String JDBC_URL = "jdbc:postgresql://localhost:5432/EmployeeDB";
//    private static final String JDBC_USER = "postgres";
//    private static final String JDBC_PASSWORD = "aarsha";
//
//    static {
//        try {
//            Class.forName("org.postgresql.Driver");
//            logger.info("PostgreSQL JDBC Driver registered.");
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//            logger.severe("PostgreSQL JDBC Driver not found. Include it in your library path.");
//        }
//    }
//
//    // Method to get all employees
//    public List<Employee> getAllEmployees() {
//        List<Employee> employees = new ArrayList<>();
//        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
//            String sql = "SELECT * FROM employees";
//            try (PreparedStatement statement = connection.prepareStatement(sql);
//                 ResultSet resultSet = statement.executeQuery()) {
//                while (resultSet.next()) {
//                    Employee employee = new Employee();
//                    employee.setEmployeeId(resultSet.getInt("employee_id"));
//                    employee.setName(resultSet.getString("name"));
//                    employee.setEmail(resultSet.getString("email"));
//                    employee.setDepartment(resultSet.getString("department"));
//                    employee.setPerformanceScore(resultSet.getInt("performance_score"));
//                    employee.setAttendance(resultSet.getInt("attendance"));
//                    employees.add(employee);
//                }
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            logger.severe("Error while fetching employees: " + e.getMessage());
//        }
//        return employees;
//    }
//
//    // Method to add a new employee
//    public void addEmployee(Employee employee) {
//        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
//            String sql = "INSERT INTO employees (employee_id, name, email, department, performance_score, attendance) VALUES (?, ?, ?, ?, ?, ?)";
//            try (PreparedStatement statement = connection.prepareStatement(sql)) {
//                statement.setString(1, employee.getName());
//                statement.setString(2, employee.getEmail());
//                statement.setString(3, employee.getDepartment());
//                statement.setInt(4, employee.getEmployeeId());
//                statement.setInt(5, employee.getPerformanceScore());
//                statement.setInt(6, employee.getAttendance());
//                statement.executeUpdate();
//                logger.info("Employee added successfully.");
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            logger.severe("Error while adding employee: " + e.getMessage());
//        }
//    }
//
//    // Method to update an existing employee
//    public void updateEmployee(Employee employee) {
//        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
//            String sql = "UPDATE employees SET name = ?, email = ?, department = ?, performance_score = ?, attendance = ? WHERE employee_id = ?";
//            try (PreparedStatement statement = connection.prepareStatement(sql)) {
//                statement.setString(1, employee.getName());
//                statement.setString(2, employee.getEmail());
//                statement.setString(3, employee.getDepartment());
//                statement.setInt(4, employee.getPerformanceScore());
//                statement.setInt(5, employee.getAttendance());
//                statement.setInt(6, employee.getEmployeeId());
//                int rowsUpdated = statement.executeUpdate();
//                if (rowsUpdated > 0) {
//                    logger.info("Employee updated successfully.");
//                } else {
//                    logger.warning("No employee found with ID: " + employee.getEmployeeId());
//                }
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            logger.severe("Error while updating employee: " + e.getMessage());
//        }
//    }
//
//    // Method to delete an employee by name and department
//    public boolean deleteEmployeeByNameAndDepartment(String name, String department) {
//        boolean deleted = false;
//        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
//            String sql = "DELETE FROM employees WHERE name = ? AND department = ?";
//            try (PreparedStatement statement = connection.prepareStatement(sql)) {
//                statement.setString(1, name);
//                statement.setString(2, department);
//                int rowsAffected = statement.executeUpdate();
//                deleted = rowsAffected > 0;
//                if (deleted) {
//                    logger.info("Employee deleted successfully.");
//                } else {
//                    logger.warning("No employee found with name: " + name + " and department: " + department);
//                }
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            logger.severe("Error while deleting employee: " + e.getMessage());
//        }
//        return deleted;
//    }
//}


package com.example.service;

import com.example.model.Employee;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class EmployeeService {

    private static final Logger logger = Logger.getLogger(EmployeeService.class.getName());

    private static final String JDBC_URL = "jdbc:postgresql://localhost:5432/EmployeeDB";
    private static final String JDBC_USER = "postgres";
    private static final String JDBC_PASSWORD = "aarsha";

    static {
        try {
            Class.forName("org.postgresql.Driver");
            logger.info("PostgreSQL JDBC Driver registered.");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            logger.severe("PostgreSQL JDBC Driver not found. Include it in your library path.");
        }
    }

    // Method to get all employees
    public List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String sql = "SELECT * FROM employees";
            try (PreparedStatement statement = connection.prepareStatement(sql);
                 ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Employee employee = new Employee();
                    employee.setEmployeeId(resultSet.getInt("employee_id"));
                    employee.setName(resultSet.getString("name"));
                    employee.setEmail(resultSet.getString("email"));
                    employee.setDepartment(resultSet.getString("department"));
                    employee.setPerformanceScore(resultSet.getInt("performance_score"));
                    employee.setAttendance(resultSet.getInt("attendance"));
                    employees.add(employee);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            logger.severe("Error while fetching employees: " + e.getMessage());
        }
        return employees;
    }

    // Method to add a new employee
    public void addEmployee(Employee employee) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String sql = "INSERT INTO employees (name, email, department, performance_score, attendance) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, employee.getName());
                statement.setString(2, employee.getEmail());
                statement.setString(3, employee.getDepartment());
                statement.setInt(4, employee.getPerformanceScore());
                statement.setInt(5, employee.getAttendance());
                statement.executeUpdate();
                logger.info("Employee added successfully.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            logger.severe("Error while adding employee: " + e.getMessage());
        }
    }

    // Method to update an existing employee
    public void updateEmployee(Employee employee) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String sql = "UPDATE employees SET name = ?, email = ?, department = ?, performance_score = ?, attendance = ? WHERE employee_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, employee.getName());
                statement.setString(2, employee.getEmail());
                statement.setString(3, employee.getDepartment());
                statement.setInt(4, employee.getPerformanceScore());
                statement.setInt(5, employee.getAttendance());
                statement.setInt(6, employee.getEmployeeId());
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    logger.info("Employee updated successfully.");
                } else {
                    logger.warning("No employee found with ID: " + employee.getEmployeeId());
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            logger.severe("Error while updating employee: " + e.getMessage());
        }
    }

    // Method to delete an employee by name and department
    public boolean deleteEmployeeByNameAndDepartment(String name, String department) {
        boolean deleted = false;
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String sql = "DELETE FROM employees WHERE name = ? AND department = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setString(2, department);
                int rowsAffected = statement.executeUpdate();
                deleted = rowsAffected > 0;
                if (deleted) {
                    logger.info("Employee deleted successfully.");
                } else {
                    logger.warning("No employee found with name: " + name + " and department: " + department);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            logger.severe("Error while deleting employee: " + e.getMessage());
        }
        return deleted;
    }
}
