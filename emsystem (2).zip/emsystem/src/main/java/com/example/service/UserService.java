package com.example.service;

public class UserService {
    // Example method to authenticate users. Replace with actual implementation.
    public String authenticateUser(String username, String password) {
        // Replace with actual user authentication logic
        if ("hr".equals(username) && "password".equals(password)) {
            return "HR";
        } else if ("employee".equals(username) && "password".equals(password)) {
            return "EMPLOYEE";
        } else {
            return null;
        }
    }
}
