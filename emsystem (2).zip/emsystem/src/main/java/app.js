document.addEventListener("DOMContentLoaded", function() {
    // You can add JavaScript code here to handle any dynamic content or additional functionality
    // For example, handling form submission with AJAX or adding event listeners

    const form = document.getElementById('employeeForm');
    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        // Gather form data
        const formData = new FormData(form);

        // Example of using Fetch API to submit the form data (optional)
        fetch('/addEmployee', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (response.ok) {
                alert('Employee added successfully');
                form.reset(); // Reset the form
            } else {
                alert('Failed to add employee');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred');
        });
    });
});
